def return_clean_text(input_text):
    return input_text.replace("_", " ").capitalize()