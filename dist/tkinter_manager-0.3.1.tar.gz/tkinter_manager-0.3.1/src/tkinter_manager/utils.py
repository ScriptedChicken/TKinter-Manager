def return_clean_text(input_text: str) -> str:
    return input_text.replace("_", " ").capitalize()
